import type { Request, Response } from 'express';
import { Router } from 'express';
import type { Module } from '../../core/moduleInit.js';
import prisma from '../../db.js';
import { isAuthenticated } from '../../middleware/auth.js';
import { onlineUsers } from '../user/wsUsers.js';
import logger from '../../services/logger.js';
import bcrypt from 'bcryptjs';
import { getParamAsNumber } from '../../utils/typeHelpers.js';


async function listUsers(res: Response) {
  try {
    const users = await prisma.users.findMany({
      include: {
        servers: true
      }
    });

    return users;
  } catch (error) {
    logger.error('Error fetching users:', error);
    res.status(500).json({ message: 'Error fetching users.' });
  }
}

const adminModule: Module = {
  info: {
    name: 'Admin Users Module',
    version: '2.0.0',
    moduleVersion: '1.0.0',
    author: 'AirLinkLab',
    license: 'MIT',
  },

  router: () => {
    const router = Router();

    router.get(
      '/admin/users',
      isAuthenticated(true),
      async (req: Request, res: Response) => {
        try {
          const userId = req.session?.user?.id;
          const user = await prisma.users.findUnique({ where: { id: userId } });
          if (!user) {
            res.redirect('/login'); return;
          }

          const users = await listUsers(res);
          const settings = await prisma.settings.findUnique({
            where: { id: 1 },
          });

          res.render('admin/users/users', {
            user,
            req,
            settings,
            users,
            onlineUsers,
          });
        } catch (error) {
          logger.error('Error fetching user:', error);
          res.redirect('/login'); return;
        }
      },
    );

    router.get(
      '/admin/users/create',
      isAuthenticated(true),
      async (req: Request, res: Response) => {
        try {
          const userId = req.session?.user?.id;
          const user = await prisma.users.findUnique({ where: { id: userId } });
          if (!user) {
            res.redirect('/login'); return;
          }
          const settings = await prisma.settings.findUnique({
            where: { id: 1 },
          });

          res.render('admin/users/create', { user, req, settings });
        } catch (error) {
          logger.error('Error fetching user:', error);
          res.redirect('/login'); return;
        }
      },
    );

    router.post(
      '/admin/users/create-user',
      isAuthenticated(true),
      async (req: Request, res: Response) => {
        const { email, username, password, isAdmin } = req.body;

        if (!email || !username || !password) {
          res.status(400).json({
            message: 'Missing required fields: email, username, or password.',
          });
          return;
        }

        if (!/^[a-zA-Z0-9]{3,20}$/.test(username)) {
          res.status(400).json({
            message: 'Username must be 3–20 characters and contain only letters and numbers.',
          });
          return;
        }

        if (password.length < 8 || !/[A-Za-z]/.test(password) || !/\d/.test(password)) {
          res.status(400).json({
            message: 'Password must be at least 8 characters and contain at least one letter and one number.',
          });
          return;
        }

        const isAdminBool = typeof isAdmin === 'boolean' ? isAdmin : isAdmin === 'true';

        try {
          const existingUser = await prisma.users.findFirst({
            where: {
              OR: [{ email }, { username }],
            },
          });

          if (existingUser) {
            res
              .status(400)
              .json({ message: 'Email or username already exists.' });
            return;
          }

          await prisma.users.create({
            data: {
              email,
              username,
              password: await bcrypt.hash(password, 12),
              isAdmin: isAdminBool,
            },
          });

          res.status(200).json({ message: 'User created successfully.' });
          return;
        } catch (error) {
          logger.error('Error creating user:', error);
          res
            .status(500)
            .json({ message: 'Error creating user. Please try again later.' });
          return;
        }
      },
    );

    router.get(
      '/admin/users/view/:id/',
      isAuthenticated(true),
      async (req: Request, res: Response) => {
        try {
          const userId = req.session?.user?.id;
          const user = await prisma.users.findUnique({ where: { id: userId } });
          if (!user) {
            res.redirect('/login'); return;
          }

          const dataUser = await prisma.users.findUnique({
            where: { id: getParamAsNumber(req.params.id) },
            include: {
              servers: true,
              loginHistory: {
                orderBy: { timestamp: 'desc' },
                take: 20
              }
            }
          });
          if (!dataUser) {
            res.redirect('/admin/users'); return;
          }
          const settings = await prisma.settings.findUnique({
            where: { id: 1 },
          });

          res.render('admin/users/user', { user, req, settings, dataUser, onlineUsers });
        } catch (error) {
          logger.error('Error fetching user:', error);
          res.redirect('/login'); return;
        }
      },
    );

    router.get(
      '/admin/users/edit/:id/',
      isAuthenticated(true),
      async (req: Request, res: Response) => {
        try {
          const userId = req.session?.user?.id;
          const user = await prisma.users.findUnique({ where: { id: userId } });
          if (!user) {
            res.redirect('/login'); return;
          }

          const dataUser = await prisma.users.findUnique({
            where: { id: getParamAsNumber(req.params.id) },
            include: {
              servers: true
            }
          });
          if (!dataUser) {
            res.redirect('/admin/users'); return;
          }

          const settings = await prisma.settings.findUnique({
            where: { id: 1 },
          });

          res.render('admin/users/edit', { user, req, settings, dataUser });
        } catch (error) {
          logger.error('Error fetching user:', error);
          res.redirect('/login'); return;
        }
      },
    );

    router.delete(
      '/admin/users/delete/:id/',
      isAuthenticated(true),
      async (req: Request, res: Response) => {
        try {
          const userId = req.session?.user?.id;
          const user = await prisma.users.findUnique({ where: { id: userId } });
          if (!user) {
            res.redirect('/login'); return;
          }

          const dataUser = await prisma.users.findUnique({
            where: { id: getParamAsNumber(req.params.id) },
          });
          if (!dataUser) {
            res.redirect('/admin/users'); return;
          }

          await prisma.users.delete({
            where: { id: getParamAsNumber(req.params.id) },
          });

          res.status(200).json({ message: 'User deleted successfully.' });
        } catch (error) {
          logger.error('Error deleting user:', error);
          res.redirect('/login'); return;
        }
      },
    );

    router.post(
      '/admin/users/update/:id/',
      isAuthenticated(true),
      async (req: Request, res: Response) => {
        try {
          const userId = req.session?.user?.id;
          const adminUser = await prisma.users.findUnique({ where: { id: userId } });
          if (!adminUser) {
            res.status(401).json({ error: 'Unauthorized' });
            return;
          }

          const targetUserId = getParamAsNumber(req.params.id);
          const targetUser = await prisma.users.findUnique({
            where: { id: targetUserId },
          });

          if (!targetUser) {
            res.status(404).json({ error: 'User not found' });
            return;
          }

          const { email, username, description, isAdmin, password, serverLimit, maxMemory, maxCpu, maxStorage } = req.body;

          // Check if email or username is already taken by another user
          if (email && email !== targetUser.email) {
            const existingUserWithEmail = await prisma.users.findFirst({
              where: {
                email,
                id: { not: targetUserId }
              },
            });

            if (existingUserWithEmail) {
              res.status(400).json({ error: 'Email already in use' });
              return;
            }
          }

          if (username && username !== targetUser.username) {
            const existingUserWithUsername = await prisma.users.findFirst({
              where: {
                username,
                id: { not: targetUserId }
              },
            });

            if (existingUserWithUsername) {
              res.status(400).json({ error: 'Username already in use' });
              return;
            }
          }

          // Prepare update data
          const updateData: Record<string, string | number | boolean | null | undefined> = {};

          if (email) {updateData.email = email;}
          if (username) {updateData.username = username;}
          if (description) {updateData.description = description;}

          if (isAdmin !== undefined) {
            updateData.isAdmin = isAdmin === true || isAdmin === 'true';
          }

          // Handle optional resource limits — null means "use global default"
          if (serverLimit !== undefined) {
            updateData.serverLimit = serverLimit === '' || serverLimit === null ? null : parseInt(serverLimit, 10);
          }
          if (maxMemory !== undefined) {
            updateData.maxMemory = maxMemory === '' || maxMemory === null ? null : parseInt(maxMemory, 10);
          }
          if (maxCpu !== undefined) {
            updateData.maxCpu = maxCpu === '' || maxCpu === null ? null : parseInt(maxCpu, 10);
          }
          if (maxStorage !== undefined) {
            updateData.maxStorage = maxStorage === '' || maxStorage === null ? null : parseInt(maxStorage, 10);
          }

          if (password && password.trim() !== '') {
            updateData.password = await bcrypt.hash(password, 12);
          }

          await prisma.users.update({
            where: { id: targetUserId },
            data: updateData,
          });

          res.status(200).json({ message: 'User updated successfully' });
        } catch (error) {
          logger.error('Error updating user:', error);
          res.status(500).json({ error: 'Internal server error' });
        }
      },
    );

    return router;
  },
};


export default adminModule;
