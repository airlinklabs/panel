import type { ApiKey } from '../generated/prisma/client.js';

declare global {
  namespace Express {
    interface Request {
      apiKey?: ApiKey;
      nonce?: string;
      lang?: string;
      translations?: Record<string, unknown>;
      cookies?: Record<string, string>;
      flashToast?: (message: string, type?: string) => void;
    }
  }
}

export {};
